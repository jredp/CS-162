//////////////////// ** Author: Jared Parkinson 
//  Utility.hpp   // *** Date: 4/26/2016
//////////////////// **** Desc: Module 1

#ifndef UTILITY_HPP
#define UTILITY_HPP

#include <iostream>

class Utility
{
private:
	//Nothing at the moment
public:
	Utility();
	int intChecker(); //Int validation
};



#endif