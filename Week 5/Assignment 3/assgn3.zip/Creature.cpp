//////////////////// ** Author: Jared Parkinson 
//  Creature.cpp  // *** Date: 5/3/2016
//////////////////// **** Desc: Assignment 3

#include "Creature.hpp"

//Construc
Creature::Creature() {
	//Pure Virtual
}
//Destruc
Creature::~Creature() {
	//Delete me
}