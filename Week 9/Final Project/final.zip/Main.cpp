//////////////////// ** Author: Jared Parkinson 
//    Main.cpp    // *** Date: 5/28/2016
//////////////////// **** Desc: Final

#include <iostream>

#include "Menu.hpp"

int main()
{
	//Activate Menu - Start Game
	Menu menuA;
	menuA.mainMenu();

	return 0;
}