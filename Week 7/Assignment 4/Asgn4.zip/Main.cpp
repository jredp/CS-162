//////////////////// ** Author: Jared Parkinson 
//    Main.cpp    // *** Date: 5/18/2016
//////////////////// **** Desc: Assignment 4

#include <iostream>

#include "Menu.hpp"

int main()
{	
	//Activate Menu with Creatures
	Menu menuA;	
	menuA.mainMenu();	

	return 0;
}